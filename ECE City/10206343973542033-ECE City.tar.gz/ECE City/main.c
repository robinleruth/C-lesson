#include "include.h"

BITMAP *calque_batiment;
BITMAP *calque_grille;
BITMAP *calque_routes;
BITMAP *calque_ressources;
BITMAP *buffer;

int main()
{
    lancerToutAllegro();
    InitialiserCalques();
    t_jeu *jeu = NULL;
    jeu = AllouerStructPrincipale();
    dessin_matrice(calque_grille);
    BITMAP* herbe= load_bitmap("images/herbe.bmp",NULL);
    BITMAP* pointeur= load_bitmap("images/pointeur.bmp",NULL);
    int mode=7;
    jeu->choix_menu = HABITATION;
    while(!key[KEY_ESC])
    {
        affichage_global(herbe, mode, pointeur);
        if(key[KEY_H])
        {
            jeu->choix_menu=HABITATION;
            AjouterElement(jeu);
            AfficherBatiments(jeu->batiments->imagesBatiments, jeu->batiments);
        }
        if(key[KEY_C])
        {
            jeu->choix_menu=CENTRALE;
            AjouterElement(jeu);
            AfficherRessources(jeu->chateaux, jeu->centrales);
        }
        if(key[KEY_V])
        {
            jeu->choix_menu=CHATEAU_EAU;
            AjouterElement(jeu);
            AfficherRessources(jeu->chateaux, jeu->centrales);
        }
        if(key[KEY_R])
        {
            jeu->choix_menu = ROUTE;
            AjouterElement(jeu);
            remplissage_calque_route(jeu->matrice, jeu->ensembleRoutes->routes, jeu->ensembleRoutes->nbroute, jeu->ensembleRoutes->bibliroute);
        }
        if(key[KEY_D])
        {
            if(jeu->matrice[mouse_x/20][mouse_y/20] != -1)
            {
                switch(jeu->matrice[mouse_x/20][mouse_y/20])
                {
                case ROUTE:
                    break;
                case HABITATION:
                    break;
                case CENTRALE:
                    break;
                case CHATEAU_EAU:
                    break;
                case CASERNE:
                    break;
                }
                ///Remettre les cases à -1
            }
        }


        /** Sous linux : sleep(), sous windows : rest() **/
        //rest(20);
        sleep(0.9);
    }

    SupprimerJeu(jeu);
    destroy_bitmap(calque_grille);

    return 0;
}
END_OF_MAIN();
