#include "include.h"

t_routes** initialiser_routes()
{
    int i;

    t_routes** route=(t_routes**)malloc(10*sizeof(t_routes*));

    for(i=0; i<10; i++)
    {
        route[i] = malloc(sizeof(t_routes));
        if(route[i] == NULL) exit(EXIT_FAILURE);

    }
    return route;
}

t_structRoute *AllouerStructRoute(){
    t_structRoute *tmp = NULL;

    tmp = malloc(1*sizeof(t_structRoute));
    if(tmp == NULL) exit(EXIT_FAILURE);

    tmp->routes = initialiser_routes();
    tmp->nbroute = 0;
    tmp->bibliroute = ChargerImage("route");

    return tmp;
}

t_routes** ajouter_route(int *nbroutes, t_routes** routes, int** grille,int x, int y)
{
    int i;
    if((*nbroutes%10==0)&&(*nbroutes!=0))
    {
        routes=(t_routes**)realloc(routes, (*nbroutes+10)*sizeof(t_routes)) ;
        for(i=*nbroutes; i<*nbroutes+10; i++)
        {
            routes[i] = malloc(1*sizeof(t_routes));
        }
    }

    //if(routes[*nbroutes] == NULL) exit(EXIT_FAILURE);
    routes[*nbroutes]->coord = malloc(sizeof(t_position));
    routes[*nbroutes]->coord->x=x/20;
    routes[*nbroutes]->coord->y=y/20;
    grille[x/20][y/20]=ROUTE ;
    *nbroutes = *nbroutes + 1;
    return routes;
}
