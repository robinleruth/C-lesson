#include "include.h"

int **AllouerMatrice()
{
    int **tab = NULL;
    int i;
    tab = (int**)malloc(TAILLE_X*sizeof(int*));
    if(tab == NULL) exit(EXIT_FAILURE);
    for(i=0; i<TAILLE_X; i++)
    {
        tab[i] = (int*)malloc(TAILLE_Y*sizeof(int));
        if(tab[i] == NULL) exit(EXIT_FAILURE);
    }
    InitialiserMatrice(tab);

    return tab;
}

void InitialiserMatrice(int **matrice)
{
    int i, j;

    for(i=0; i<TAILLE_X; i++)
    {
        for(j=0; j<TAILLE_Y; j++)
        {
            matrice[i][j] = -1;
        }
    }
}

t_jeu *AllouerStructPrincipale()
{

    t_jeu *pt = NULL;
    pt = malloc(1*sizeof(t_jeu));
    if(pt == NULL) exit(EXIT_FAILURE);
    pt->matrice = AllouerMatrice();
    pt->batiments = AllouerBatiments();
    pt->ensembleRoutes = AllouerStructRoute();
    pt->chateaux = AllouerChateaux();
    pt->centrales = AllouerCentrales();
    pt->choix_menu = RIEN;
    return pt;
}

char** matrice_adjacence(int**grille)
{
    int i,j,valeur;
    char** matrice;
    matrice=(char**)malloc(TAILLE_X*TAILLE_Y*sizeof(char*));
    for(i=0; i<TAILLE_X*TAILLE_Y; i++)
    {
        matrice[i]=(char*)malloc(TAILLE_X*TAILLE_Y*sizeof(char));
    }
    for(i=0; i<TAILLE_X; i++)
    {
        for(j=0; j<TAILLE_Y; j++)
        {
            valeur=grille[i][j];
            if(valeur==0) matrice[TAILLE_Y*i+j][j]=0;
            else
            {
                if(valeur>=8) //A GAUCHE
                {
                    valeur-=8;
                    matrice[35*i+j][35*i+j-1]=1;
                }
                if(valeur>=4) //EN BAS
                {
                    valeur-=4;
                    matrice[35*i+j][35*i+j+TAILLE_X]=1;
                }
                if(valeur>=2) //A DROITE
                {
                    valeur-=2;
                    matrice[35*i+j][35*i+j+1]=1;
                }
                if(valeur>=1) //EN HAUT
                {
                    matrice[35*i+j][35*i+j-TAILLE_X]=1;
                }
            }
        }
    }
    return matrice;
}

void SupprimerMatrice(int **tab)
{
    int i;
    for(i=0; i<TAILLE_X; i++)
    {
        free(tab[i]);
    }
    free(tab);
}

void SupprimerJeu(t_jeu *pt)
{
    SupprimerMatrice(pt->matrice);
    SupprimerTableauHabitation(pt->batiments->habitations, pt->batiments->tailleTableau);
    free(pt->batiments);
    //SupprimerRoutes(pt->routes);
    SupprimerTableauCentrale(pt->centrales->centrales, pt->centrales->nb_centrales);
    SupprimerTableauChateauDeau(pt->chateaux->chateaux, pt->chateaux->nb_chateaux);

    free(pt);
    pt = NULL;
}

void AjouterElement(t_jeu *jeu)
{
    switch(jeu->choix_menu)
    {
    case RIEN:
        break;
    case ROUTE:
        jeu->ensembleRoutes->routes = ajouter_route(&jeu->ensembleRoutes->nbroute, jeu->ensembleRoutes->routes, jeu->matrice, mouse_x, mouse_y);
        jeu->choix_menu = RIEN;
        break;
    case HABITATION:
        jeu->batiments->habitations = AjouterHabitation(jeu->batiments->habitations, &jeu->batiments->tailleTableau, &jeu->batiments->nb_habitation);
        jeu->choix_menu = RIEN;
        break;
    case CENTRALE:
        jeu->centrales->centrales = AjouterCentrale(jeu->centrales->centrales, &jeu->centrales->tailleTableauCentrale, &jeu->centrales->nb_centrales);
        jeu->choix_menu = RIEN;
        break;
    case CHATEAU_EAU:
        jeu->chateaux->chateaux = AjouterChateau(jeu->chateaux->chateaux, &jeu->chateaux->tailleTableauChateau, &jeu->chateaux->nb_chateaux);
        jeu->choix_menu = RIEN;
        break;
    case CASERNE:
        jeu->choix_menu = RIEN;
        break;
    }
}



/// un poids r�el sup�rieur � la plus grande longueur totale
/// Proc�dure qui recherche tous les plus courts chemins d�un graphe valu� positivement
/// depuis un sommet de r�f�rence
/// Param�tres :
/// adjacencePoids : matrice d�adjacence pond�r�e du graphe
/// TAILLE_X*TAILLE_Y : nombre de sommets
/// s : num�ro de sommet de r�f�rence
/// l : tableau dynamique allou� des longueurs minimales des sommets depuis s
/// pred : tableau dynamique allou� des pr�d�cesseurs des sommets
void dijkstra (char**adjacencePoids, int point_depart,int point_cherche)
{
/// Variables locales
    int *marques ; /// tableau dynamique indiquant si les sommets sont marqu�s ou non
    int x, y, xmin ; /// num�ros de sommets interm�diaires
    int i;
    int *l;
    int *pred;
    float min ; /// distance minimale du prochain sommet � marquer
    int nb = 0 ; /// nombre de sommets marqu�s initialis� � 0
/// Allouer le tableau marques de taille � TAILLE_X*TAILLE_Y �
    marques=(int*)malloc(TAILLE_X*TAILLE_Y*sizeof(int));
    l=(int*)malloc(TAILLE_X*TAILLE_Y*sizeof(int));
    pred=(int*)malloc(TAILLE_X*TAILLE_Y*sizeof(int));
/// Initialiser les marquages � 0 et les longueurs minimales � l�INFINI
    for(i=0; i<TAILLE_X*TAILLE_Y; i++)
    {
        marques[i]=0;
        l[i]=INFINI;
    }
/// Initialiser longueur de s nombre de sommets marqu�s � 0
    l[point_depart] = nb;
/// Tant que les sommets ne sont pas tous marqu�s
    while ((nb<TAILLE_X*TAILLE_Y)&&(xmin!=point_cherche))
    {
/// Initialiser la longueur minimale � l�INFINI
        min = INFINI ;
/// Pour tous les sommets x non marqu�s de longueur minimale
/// Stocker le sommet � xmin � de longueur minimale
        for (x=0 ; x<TAILLE_X*TAILLE_Y ; x++)
        {
            if (!marques[x] && l[x]<min)
            {
                xmin = x ;
                min = l[x] ;
            }
        }
/// Marquer le sommet de longueur minimale � xmin � et incr�menter � nb �
        marques[xmin] = 1 ;
        nb++ ;
/// Pour tous les sommets y adjacents � � xmin � et non marqu�s
/// Chercher la plus petite distance de y � � xmin �
/// Stocker le pr�d�cesseur � xmin � de y
        for (y=0 ; y<TAILLE_X*TAILLE_Y ; y++)
            if (adjacencePoids[xmin][y] && !marques[y] && l[xmin]+adjacencePoids[xmin][y]<l[y])
            {
                l[y] = l[xmin] + adjacencePoids[xmin][y] ;
                pred[y] = xmin ;
            }
    }
}
