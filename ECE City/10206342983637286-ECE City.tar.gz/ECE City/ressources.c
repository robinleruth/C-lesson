#include "include.h"

t_eau *CreerChateauDEau()
{
    t_eau *chateau = NULL;

    chateau = malloc(sizeof(t_eau));
    if(chateau == NULL) exit(EXIT_FAILURE);

    chateau->coord = malloc(sizeof(t_position));
    if(chateau->coord == NULL) exit(EXIT_FAILURE);

    chateau->coord->x = mouse_x;
    chateau->coord->y = mouse_y;
    chateau->qtEau = QTE_EAU;

    return chateau;
}

t_elec *CreerCentrale()
{
    t_elec *centrale = NULL;

    centrale = malloc(sizeof(t_elec));
    if(centrale == NULL) exit(EXIT_FAILURE);

    centrale->coord = malloc(sizeof(t_position));
    if(centrale->coord == NULL) exit(EXIT_FAILURE);

    centrale->coord->x = mouse_x;
    centrale->coord->y = mouse_y;
    centrale->qtElec = QTE_ELEC;

    return centrale;
}

t_eau **AllouerTableauChateauDEau()
{
    t_eau **tab = NULL;
    int i;

    tab = malloc(NB_CHATEAU_INITIAL*sizeof(t_eau*));
    if(tab == NULL) exit(EXIT_FAILURE);

    for(i=0; i<NB_CHATEAU_INITIAL; i++)
    {
        tab[i] = NULL;
    }

    return tab;
}

t_elec **AllouerTableauCentrale()
{
    t_elec **tab = NULL;
    int i;

    tab = malloc(NB_CENTRALE_INITIAL*sizeof(t_elec*));
    if(tab == NULL) exit(EXIT_FAILURE);

    for(i=0; i<NB_CENTRALE_INITIAL; i++)
    {
        tab[i] = NULL;
    }

    return tab;
}

void SupprimerChateauDEau(t_eau *ChateauDEau)
{
    free(ChateauDEau);
    ChateauDEau = NULL;
}

void SupprimerTableauChateauDeau(t_eau **tab, int tailleActuelle)
{
    int i;
    for(i=0; i<tailleActuelle; i++)
    {
        SupprimerChateauDEau(tab[i]);
    }
    free(tab);
    tab = NULL;
}

void SupprimerCentrale(t_elec* centrale)
{
    free(centrale);
    centrale = NULL;
}

void SupprimerTableauCentrale(t_elec **centrale, int tailleActuelle)
{
    int i;
    for(i=0; i<tailleActuelle; i++)
    {
        SupprimerCentrale(centrale[i]);
    }
    free(centrale);
    centrale = NULL;
}

t_eau **AugmenterTailleTableauChateauDEau(t_eau **tab, int *tailleActuelle, int *nbChat)
{
    tab = realloc(tab, *tailleActuelle*3/2*sizeof(t_eau**));
    *tailleActuelle = *tailleActuelle*3/2;

    *nbChat = *nbChat + 1;
    return tab;
}

t_elec **AugmenterTailleTableauCentrales(t_elec **tab, int *tailleActuelle, int *nbCent)
{
    tab = realloc(tab, *tailleActuelle*3/2*sizeof(t_elec**));
    *tailleActuelle = *tailleActuelle*3/2;

    *nbCent = *nbCent + 1 ;
    return tab;
}

t_chateaux *AllouerChateaux()
{
    t_chateaux *chatte = NULL;

    chatte = malloc(sizeof(t_chateaux));
    if(chatte == NULL) exit(EXIT_FAILURE);
    chatte->chateaux = AllouerTableauChateauDEau();
    chatte->nb_chateaux = 0;
    chatte->tailleTableauChateau = NB_CHATEAU_INITIAL;
    chatte->image = ChargerImageChateau();

    return chatte;
}

t_centrales *AllouerCentrales()
{
    t_centrales *centre = NULL;

    centre = malloc(sizeof(t_centrales));
    if(centre == NULL) exit(EXIT_FAILURE);

    centre->centrales = AllouerTableauCentrale();
    centre->nb_centrales = 0;
    centre->tailleTableauCentrale = NB_CENTRALE_INITIAL;
    centre->image = ChargerImageCentrale();

    return centre;
}

t_eau **AjouterChateau(t_eau **tab, int *tailleActuelle, int *nbChat)
{
    int i = 0;

    while(tab[i] != NULL)
    {
        i++;
    }

    if(i== *tailleActuelle)
    {
        tab = AugmenterTailleTableauChateauDEau(tab, tailleActuelle, nbChat);
        tab[i+1] = CreerChateauDEau();
        *nbChat = *nbChat + 1 ;
    }

    else
    {
        tab[i] = CreerChateauDEau();
        *nbChat = *nbChat + 1 ;
    }

    return tab;
}

t_elec **AjouterCentrale(t_elec **tab, int *tailleActuelle, int *nbCentre)
{
    int i = 0;

    while(tab[i] != NULL)
    {
        i++;
    }

    if(i == *tailleActuelle)
    {
        tab = AugmenterTailleTableauCentrales(tab, tailleActuelle, nbCentre);
        tab[i+1] = CreerCentrale();
        *nbCentre = *nbCentre + 1;

    }
    else
    {
        tab[i] = CreerCentrale();
        *nbCentre = *nbCentre + 1;
    }

    return tab;
}

BITMAP *ChargerImageChateau(){
    BITMAP *bit = NULL;

    bit = load_bitmap("images/chateau_d_eau.bmp", NULL);

    return bit;
}

BITMAP *ChargerImageCentrale(){
    BITMAP *bit = NULL;

    bit = load_bitmap("images/centrale.bmp", NULL);

    return bit;
}
