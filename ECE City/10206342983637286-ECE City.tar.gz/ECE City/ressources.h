#ifndef RESSOURCES_H_INCLUDED
#define RESSOURCES_H_INCLUDED

typedef struct eau
{
    t_position *coord;
    int qtEau;
} t_eau;

typedef struct chateau
{
    t_eau **chateaux;
    int nb_chateaux;
    int tailleTableauChateau;
    BITMAP *image;
} t_chateaux;

typedef struct elec
{
    t_position *coord;
    int qtElec;
} t_elec;

typedef struct centrale
{
    t_elec **centrales;
    int nb_centrales;
    int tailleTableauCentrale;
    BITMAP *image;
} t_centrales;

t_eau *CreerChateauDEau();

t_elec *CreerCentrale();

t_eau **AllouerTableauChateauDEau();

t_elec **AllouerTableauCentrale();

void SupprimerChateauDEau(t_eau *ChateauDEau);

void SupprimerTableauChateauDeau(t_eau **tab, int tailleActuelle);

void SupprimerCentrale(t_elec *centrale);

void SupprimerTableauCentrale(t_elec **centrale, int tailleActuelle);

t_eau **AugmenterTailleTableauChateauDEau(t_eau **tab, int *tailleActuelle, int *nbChat);

t_elec **AugmenterTailleTableauCentrales(t_elec **tab, int *tailleActuelle, int *nbCent);

//Allouer le t_eau ** et met le nombre de chateau à 0;
t_chateaux *AllouerChateaux();

//Alloue le t_elec ** et met le nombre de centrales à 0
t_centrales *AllouerCentrales();

t_eau **AjouterChateau(t_eau** tab, int *tailleActuelle, int *nbChat);

t_elec **AjouterCentrale(t_elec **tab, int *tailleActuelle, int *nbCentre);

BITMAP *ChargerImageChateau();

BITMAP *ChargerImageCentrale();

#endif // RESSOURCES_H_INCLUDED
