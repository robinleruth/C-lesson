#include "include.h"

void lancerToutAllegro()
{
    allegro_init();
    install_keyboard();
    install_mouse();
    set_color_depth(desktop_color_depth());
    if (set_gfx_mode(GFX_AUTODETECT_WINDOWED,LARGEUR,HAUTEUR,0,0)!=0)
    {
        allegro_message("probleme mode graphique : %s", allegro_error);
        allegro_exit();
        exit(EXIT_FAILURE);
    }
    clear_to_color(screen,makecol(255,255,255));
}

BITMAP* creation_calque()
{
    BITMAP* image;
    image = create_bitmap(LARGEUR,HAUTEUR);
    clear_to_color(image,makecol(255,0,255));
    return image;
}

void InitialiserCalques()
{
    calque_batiment = creation_calque();
    calque_grille = creation_calque();
    calque_routes = creation_calque();
    calque_ressources = creation_calque();
}

void afficher_route(int x, int y, int** grille, BITMAP **bibroute)
{
    int route_disposition=0 ;
    if(x>0 && x < TAILLE_X)
    {
        if(grille[x-1][y]==ROUTE) route_disposition+=8;

        if(grille[x+1][y]==ROUTE) route_disposition+=2;
    }

    if(y>0 && y < TAILLE_Y)
    {
        if(grille[x][y-1]==ROUTE) route_disposition+=1;

        if(grille[x-1][y]==ROUTE) route_disposition+=4;
    }
    blit(bibroute[route_disposition],calque_routes,0,0,x*20, y*20,WIDTH,HEIGHT);
}

void remplissage_calque_route(int** grille, t_routes** routes, int nbroutes, BITMAP **bibroute)
{
    clear_to_color(calque_routes,makecol(255,0,255));
    int i;
    for(i=0; i<nbroutes; i++)
    {
        afficher_route(routes[i]->coord->x,routes[i]->coord->y,grille, bibroute);
    }
}


void dessin_matrice(BITMAP*calque)
{
    int i;
    for(i=0; i<TAILLE_X; i++)
    {
        line(calque,i*20,0,i*20,HAUTEUR,0);
    }
    for(i=0; i<TAILLE_Y; i++)
    {
        line(calque,0,i*20,LARGEUR,i*20,0);
    }
}

void AfficherBatiments(BITMAP **tab, t_batiments *batiments)
{
    int i;
    for(i=0; i < batiments->tailleTableau; i++)
    {
        if(batiments->habitations[i] != NULL)
        {
            switch(batiments->habitations[i]->stade)
            {
            case TERRAIN_VAGUE:
                blit(tab[TERRAIN_VAGUE], calque_batiment, 0, 0, batiments->habitations[i]->coord->x, batiments->habitations[i]->coord->y, LONGUEUR_BATIMENTS, LARGEUR_BATIMENTS);
                break;
            case CABANE:
                blit(tab[CABANE], calque_batiment, 0, 0, batiments->habitations[i]->coord->x, batiments->habitations[i]->coord->y, LONGUEUR_BATIMENTS, LARGEUR_BATIMENTS);
                break;
            case MAISON:
                blit(tab[MAISON], calque_batiment, 0, 0, batiments->habitations[i]->coord->x, batiments->habitations[i]->coord->y, LONGUEUR_BATIMENTS, LARGEUR_BATIMENTS);
                break;
            case IMMEUBLE:
                blit(tab[IMMEUBLE], calque_batiment, 0, 0, batiments->habitations[i]->coord->x, batiments->habitations[i]->coord->y, LONGUEUR_BATIMENTS, LARGEUR_BATIMENTS);
                break;
            case GRATTE_CIEL:
                blit(tab[GRATTE_CIEL], calque_batiment, 0, 0, batiments->habitations[i]->coord->x, batiments->habitations[i]->coord->y, LONGUEUR_BATIMENTS, LARGEUR_BATIMENTS);
                break;
            }
        }
    }
}

void AfficherRessources(t_chateaux *chat, t_centrales *elec){
    int i;
    for(i=0; i<chat->tailleTableauChateau;i++){
        if(chat->chateaux[i] != NULL){
            blit(chat->image, calque_ressources, 0, 0, chat->chateaux[i]->coord->x, chat->chateaux[i]->coord->y, LONGUEUR_BATIMENTS, LARGEUR_BATIMENTS);
        }
    }
    for(i=0;i<elec->tailleTableauCentrale;i++){
        if(elec->centrales[i] != NULL){
            blit(elec->image, calque_ressources, 0, 0, elec->centrales[i]->coord->x, elec->centrales[i]->coord->y, LONGUEUR_BATIMENTS, LARGEUR_BATIMENTS);
        }
    }
}
