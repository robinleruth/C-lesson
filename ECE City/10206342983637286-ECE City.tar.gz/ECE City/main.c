#include "include.h"

BITMAP *calque_batiment;
BITMAP *calque_grille;
BITMAP *calque_routes;
BITMAP *calque_ressources;

int main()
{
    lancerToutAllegro();
    InitialiserCalques();
    t_jeu *jeu = NULL;
    jeu = AllouerStructPrincipale();
    //InitialiserCalques();
    dessin_matrice(calque_grille);
    jeu->choix_menu = HABITATION;
    //bib_routes=ChargerImage("route");
//    bib_stades=ChargerImage("stade");
    while(!key[KEY_ESC])
    {
        blit(calque_grille,screen,0,0,0,0,LARGEUR,HAUTEUR);
        blit(calque_routes,screen,0,0,0,0,LARGEUR,HAUTEUR);
        blit(calque_batiment, screen, 0, 0, 0, 0, LARGEUR, HAUTEUR);
        blit(calque_ressources, screen, 0, 0, 0, 0, LARGEUR, HAUTEUR);
        if(key[KEY_H]){
            jeu->choix_menu=HABITATION;
            AjouterElement(jeu);
            AfficherBatiments(jeu->batiments->imagesBatiments, jeu->batiments);
        }
        if(key[KEY_C]){
            jeu->choix_menu=CENTRALE;
            AjouterElement(jeu);
            AfficherRessources(jeu->chateaux, jeu->centrales);
        }
        if(key[KEY_V]){
            jeu->choix_menu=CHATEAU_EAU;
            AjouterElement(jeu);
            AfficherRessources(jeu->chateaux, jeu->centrales);
        }
        if(key[KEY_R]){
            jeu->choix_menu = ROUTE;
            AjouterElement(jeu);
            remplissage_calque_route(jeu->matrice, jeu->ensembleRoutes->routes, jeu->ensembleRoutes->nbroute, jeu->ensembleRoutes->bibliroute);
        }


        /** Sous linux : sleep(), sous windows : rest() **/
        //rest(20);
        sleep(0.3);
    }

    SupprimerJeu(jeu);
    destroy_bitmap(calque_grille);

    return 0;
}
END_OF_MAIN();
